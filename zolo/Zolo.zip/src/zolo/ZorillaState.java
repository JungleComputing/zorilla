package zolo;

public enum ZorillaState {
    DEAD, RUNNING, PAUSED
}
