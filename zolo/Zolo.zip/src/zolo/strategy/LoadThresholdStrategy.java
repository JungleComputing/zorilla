package zolo.strategy;

public class LoadThresholdStrategy extends Strategy implements StrategyInterface {

    // @todo: implement

    public void run() {
    }

    public void check() {
    }

}
