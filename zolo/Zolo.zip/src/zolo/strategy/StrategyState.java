package zolo.strategy;

public enum StrategyState {
    NO_GO, GO, ERROR
}
