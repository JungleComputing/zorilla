package zolo;

public class ZoloException extends Exception {
    ZoloException(String reason) {
        super(reason);
    }
}
